#ifndef INIT_H_
#define INIT_H_

void init_response(int sock_index, char *cntrl_response_payload);

#endif